package com.example.FirstAPI.MODEL.service.CRUDcontroller;

import com.example.FirstAPI.MODEL.service.CRUDserve;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api") // Optional: Adds a prefix to all endpoints
public class CRUDcontroller {
    @Autowired
    private CRUDserve server;

    @PostMapping("/add")
    public String addData(@RequestBody Map<String, String> request) {
        String key = request.get("key");
        String value = request.get("value");
        return  server.addvalue(key, value);
    }

    @GetMapping("/get")
    public String getData(@RequestParam String key) {
        return server.getvalue(key);
    }

    @GetMapping("/all")
    public Map<String, String> getAllData() {
        return server.showAll();
    }
    @GetMapping("df")
    public String delete(@RequestParam String k){

        return  server.removevalue(k);
    }
    @PutMapping("modi")
    public String modified(@RequestBody Map<String,String>update){
        String k=update.get("key");
        String V=update.get("value");
        return server.update(k,V);
    }
    @DeleteMapping("dele")
    public String delete1(@RequestParam String k){
        return server.Deletevale(k);

    }


}

















