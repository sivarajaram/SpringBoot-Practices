package com.example.FirstAPI.MODEL.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class CRUDserve {
    private Map<String, String> map = new HashMap<>();

    public String addvalue(String key, String value) {
        map.put("1","VINIL");
        map.put(key, value);
        return "Value added";
    }

    public String getvalue(String key) {
        return map.getOrDefault(key, "Key not found");
    }

    public String removevalue(String key) {
       map.remove(key);
       return "value removed";
    }

    // Corrected method to return all data
    public Map<String, String> showAll() {
        return map;
    }

    public String update(String k, String v) {


        if(map.containsKey(k)){
            String a=map.remove(k);
            map.put(k,a);
           // return "key changed";
        }
        map.put(k,v);
        return "Modified";

    }

    public String Deletevale(String k) {
        map.remove(k);
        return"Value deleted";
    }
}
