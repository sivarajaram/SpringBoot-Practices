package com.example.sqlIntergration.controller;

import com.example.sqlIntergration.Model.Student;
import com.example.sqlIntergration.service.sqlservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class sqlcontroller {
    @Autowired
    sqlservice sq;

    @GetMapping("/allstud")
    public List<Student> getall(){

        return sq.getall();
    }
    @PostMapping("alladd")
    public String addall(@RequestBody Student student){

        sq.addall(student);
        return "database stored";

    }
    @DeleteMapping("delete")
    public String dele(@RequestParam int k){
        return sq.delete(k);
    }

    @PutMapping("modifid")
    public String mod(@RequestBody Student student ){

        return sq.Modified(student);

    }

}
