package com.example.sqlIntergration.repository;

import com.example.sqlIntergration.Model.Student;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface repository extends JpaRepository<Student,Integer> {
}
