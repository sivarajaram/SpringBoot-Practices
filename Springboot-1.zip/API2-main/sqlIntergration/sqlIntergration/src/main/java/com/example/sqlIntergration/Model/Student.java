package com.example.sqlIntergration.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.stereotype.Service;

@Service
@Entity
public class Student {


    @Id
    private int Rollno;
    private String Name;
    private String Technology;

    public String getTechnology() {
        return Technology;
    }

    public void setTechnology(String technology) {
        Technology = technology;
    }



    public int getRollno() {
        return Rollno;
    }

    public void setRollno(int rollno) {
        Rollno = rollno;
    }




    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
    public Student(int rollno,String name,String Tech ) {
      this.Rollno=rollno;
        this.Name = name;
        this.Technology=Tech;
    }

    public Student() {

    }
}



