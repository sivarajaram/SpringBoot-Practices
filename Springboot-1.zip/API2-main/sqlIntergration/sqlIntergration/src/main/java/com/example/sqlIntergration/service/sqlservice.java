package com.example.sqlIntergration.service;

import com.example.sqlIntergration.Model.Student;
import com.example.sqlIntergration.repository.repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class sqlservice {
    @Autowired
    repository rep;

    public List<Student> getall() {

        return rep.findAll();

    }

    public void addall(Student student) {

        rep.save(student);
    }
    public String delete(int id){
        rep.deleteById(id);
        return "value deleted";
    }

    public String Modified(Student student) {

        rep.save(student);
        return "modified";
    }
}
