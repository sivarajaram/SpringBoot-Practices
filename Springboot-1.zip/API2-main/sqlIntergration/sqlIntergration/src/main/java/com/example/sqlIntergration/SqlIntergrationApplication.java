package com.example.sqlIntergration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlIntergrationApplication {

	public static void main(String[] args) {

		SpringApplication.run(SqlIntergrationApplication.class, args);
	}

}
